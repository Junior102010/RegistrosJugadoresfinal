﻿using Microsoft.EntityFrameworkCore;
using RegistrosJugadores.DAL;
using RegistrosJugadores.Models;
using System.Linq.Expressions;

namespace RegistrosJugadores.Services
{
    public class PartidasServices(IDbContextFactory<Contexto> DbFactory)
    {
        public async Task<bool> Guardar(Partidas Partida)
        {
            if (!await Existe(Partida.PartidaId))
            {
                return await Insertar(Partida);
            }
            else
            {
                return await Modificar(Partida);
            }
        }

        public async Task<bool> Existe(int id)
        {
            await using var context = await DbFactory.CreateDbContextAsync();
            return await context.Partidas.AnyAsync(j => j.PartidaId == id);
        }

        public async Task<bool> Insertar(Partidas Partida)
        {
            await using var contexto = await DbFactory.CreateDbContextAsync();
            contexto.Partidas.Add(Partida);
            return await contexto.SaveChangesAsync() > 0;
        }

        public async Task<bool> Modificar(Partidas Partida)
        {
            await using var contexto = await DbFactory.CreateDbContextAsync();
            contexto.Update(Partida);
            return await contexto.SaveChangesAsync() > 0;
        }

        public async Task<Partidas?> Buscar(int id)
        {
            await using var contexto = await DbFactory.CreateDbContextAsync();
            return await contexto.Partidas
                .AsNoTracking()
                .FirstOrDefaultAsync(j => j.PartidaId == id);
        }


        public async Task<bool> Eliminar(int id)
        {
            await using var contexto = await DbFactory.CreateDbContextAsync();

            return await contexto.Partidas.Where(j => j.PartidaId == id).ExecuteDeleteAsync() > 0;
        }

        public async Task<List<Partidas>> Listar(Expression<Func<Partidas, bool>> criterio)
        {
            await using var contexto = await DbFactory.CreateDbContextAsync();
            return await contexto.Partidas.Where(criterio).AsNoTracking().ToListAsync();

        }

    }
}
